package com.checkers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Statistics implements java.io.Serializable{

    private List<Player> players = new ArrayList<>();
    private HashMap<String, Integer> wins = new HashMap<>();
    private HashMap<String, Integer> loses= new HashMap<>();
    private HashMap<String, Integer> draws = new HashMap<>();

    //TODO
    public void addWin(){

    }
    //TODO
    public void  addLoss(){

    }
    //TODO
    public void addDraw(){

    }
}
