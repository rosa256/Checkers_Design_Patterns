package com.checkers.Command;

import java.util.Stack;

public class CommandManager {

    private Stack<Command> undoStack;
    private Stack<Command> redoStack;

    //TODO
    public void Move(Command command){

    }

    //TODO
    public void undo(){

    }

    //TODO
    public void redo(){

    }
}
