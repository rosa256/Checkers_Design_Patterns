package com.checkers.Command;

import com.checkers.Decorator.Piece;

public class Command {

    //TODO
    public void Move(int x, int y, int to_x, int to_y, Piece piece){

    }

    //TODO
    public void undo(){

    }

    //TODO
    public void redo(){

    }
}
