package com.checkers.Strategy;

import java.util.Timer;

public class EasyMode extends Strategy{

    //TODO

    @Override
    public void timeStrategy(Timer playerTimer) {

    }
}
