package com.checkers.Strategy;

import java.util.Timer;

public class Strategy {

    //TODO
    public void timeStrategy(Timer playerTimer){

    }
}
