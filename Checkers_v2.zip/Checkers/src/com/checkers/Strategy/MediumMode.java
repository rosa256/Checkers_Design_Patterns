package com.checkers.Strategy;

import java.util.Timer;

public class MediumMode extends Strategy{

    //TODO

    @Override
    public void timeStrategy(Timer playerTimer) {

    }
}
