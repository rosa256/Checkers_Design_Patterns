package com.checkers.Observer;

public interface ISubject {

    //TODO
    void register(IObserver observer);

    //TODO
    void unregister(IObserver observer);

    //TODO
    //void notify();
}
