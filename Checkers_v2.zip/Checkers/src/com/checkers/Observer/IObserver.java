package com.checkers.Observer;

public interface IObserver {

    //TODO
    void update();
}
